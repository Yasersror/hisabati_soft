import 'dart:async';
import 'package:flutter/material.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 44,
                backgroundColor: Color(0xFFE3F2FD),
                child: Icon(Icons.bar_chart, color: Color(0xFF0D47A1), size: 46),
              ),
              SizedBox(height: 14),
              Text('💼 حساباتي سوفت', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Color(0xFF0D47A1))),
              SizedBox(height: 6),
              Text('نظام مبيعات ومخزون مبسط', style: TextStyle(fontSize: 14, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }
}