import 'package:flutter/material.dart';

class ReportsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('التقارير')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Text('ملخص المبيعات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Expanded(
                child: ListView(
                  children: [
                    ListTile(
                      title: Text('فاتورة رقم 1'),
                      subtitle: Text('المجموع: 1500 ريال'),
                    ),
                    ListTile(
                      title: Text('فاتورة رقم 2'),
                      subtitle: Text('المجموع: 2200 ريال'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}