import 'package:flutter/material.dart';
import 'sales_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('حساباتي سوفت'),
          actions: [
            IconButton(
              icon: Icon(Icons.settings),
              onPressed: () {
                // زر الإعدادات
              },
            ),
          ],
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                child: Text('المبيعات'),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => SalesScreen()));
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text('التقارير'),
                onPressed: () {
                  // صفحة التقارير
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}