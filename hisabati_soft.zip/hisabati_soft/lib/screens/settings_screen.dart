import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storeNameCtrl = TextEditingController(text: 'متجر حساباتي');
  String currency = 'ريال';

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('الإعدادات')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              TextField(controller: _storeNameCtrl, decoration: InputDecoration(labelText: 'اسم المتجر')),
              SizedBox(height: 10),
              DropdownButton<String>(
                value: currency,
                items: ['ريال', 'دولار'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (val) {
                  setState(() { currency = val!; });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text('حفظ الإعدادات'),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم حفظ الإعدادات مؤقتًا')));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}