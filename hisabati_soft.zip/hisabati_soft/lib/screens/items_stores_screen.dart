import 'package:flutter/material.dart';

class ItemsStoresScreen extends StatefulWidget {
  @override
  _ItemsStoresScreenState createState() => _ItemsStoresScreenState();
}

class _ItemsStoresScreenState extends State<ItemsStoresScreen> {
  final _itemNameCtrl = TextEditingController();
  final _storeNameCtrl = TextEditingController();

  List<String> items = [];
  List<String> stores = [];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('الأصناف والمخازن')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              // الأصناف
              Row(
                children: [
                  Expanded(child: TextField(controller: _itemNameCtrl, decoration: InputDecoration(labelText: 'اسم الصنف'))),
                  SizedBox(width: 10),
                  ElevatedButton(
                    child: Text('إضافة صنف'),
                    onPressed: () {
                      if (_itemNameCtrl.text.isEmpty) return;
                      setState(() { items.add(_itemNameCtrl.text); _itemNameCtrl.clear(); });
                    },
                  ),
                ],
              ),
              SizedBox(height: 6),
              Text('الأصناف:', style: TextStyle(fontWeight: FontWeight.bold)),
              Expanded(
                child: ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (_, index) => ListTile(
                    title: Text(items[index]),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () { setState(() { items.removeAt(index); }); },
                    ),
                  ),
                ),
              ),
              Divider(),
              // المخازن
              Row(
                children: [
                  Expanded(child: TextField(controller: _storeNameCtrl, decoration: InputDecoration(labelText: 'اسم المخزن'))),
                  SizedBox(width: 10),
                  ElevatedButton(
                    child: Text('إضافة مخزن'),
                    onPressed: () {
                      if (_storeNameCtrl.text.isEmpty) return;
                      setState(() { stores.add(_storeNameCtrl.text); _storeNameCtrl.clear(); });
                    },
                  ),
                ],
              ),
              SizedBox(height: 6),
              Text('المخازن:', style: TextStyle(fontWeight: FontWeight.bold)),
              Expanded(
                child: ListView.builder(
                  itemCount: stores.length,
                  itemBuilder: (_, index) => ListTile(
                    title: Text(stores[index]),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () { setState(() { stores.removeAt(index); }); },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}