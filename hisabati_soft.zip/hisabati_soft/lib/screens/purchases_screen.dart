import 'package:flutter/material.dart';

class PurchasesScreen extends StatefulWidget {
  @override
  _PurchasesScreenState createState() => _PurchasesScreenState();
}

class _PurchasesScreenState extends State<PurchasesScreen> {
  final _invoiceNoCtrl = TextEditingController();
  final _dateCtrl = TextEditingController(text: DateTime.now().toString().split(' ')[0]);
  final _supplierCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String paymentType = 'نقد';
  String selectedStore = 'المخزن الافتراضي';
  String currency = 'ريال';

  List<Map<String, dynamic>> purchaseItems = [];
  final _itemNameCtrl = TextEditingController();
  final _itemQtyCtrl = TextEditingController();
  final _itemPriceCtrl = TextEditingController();

  double get total => purchaseItems.fold(0, (sum, item) => sum + item['total']);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('المشتريات')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: TextField(controller: _invoiceNoCtrl, decoration: InputDecoration(labelText: 'رقم الفاتورة'))),
                    SizedBox(width: 10),
                    Expanded(child: TextField(controller: _dateCtrl, decoration: InputDecoration(labelText: 'تاريخ الفاتورة'))),
                  ],
                ),
                SizedBox(height: 10),
                TextField(controller: _supplierCtrl, decoration: InputDecoration(labelText: 'اسم المورد')),
                TextField(controller: _notesCtrl, decoration: InputDecoration(labelText: 'ملاحظات')),
                SizedBox(height: 10),
                Row(
                  children: [
                    DropdownButton<String>(
                      value: paymentType,
                      items: ['نقد', 'آجل'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (val) { setState(() { paymentType = val!; }); },
                    ),
                    SizedBox(width: 10),
                    DropdownButton<String>(
                      value: selectedStore,
                      items: ['المخزن الافتراضي'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (val) { setState(() { selectedStore = val!; }); },
                    ),
                    SizedBox(width: 10),
                    DropdownButton<String>(
                      value: currency,
                      items: ['ريال','دولار'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (val) { setState(() { currency = val!; }); },
                    ),
                  ],
                ),
                Divider(height: 20, color: Colors.black),
                Row(
                  children: [
                    Expanded(child: TextField(controller: _itemNameCtrl, decoration: InputDecoration(labelText: 'اسم الصنف'))),
                    SizedBox(width: 6),
                    Expanded(child: TextField(controller: _itemQtyCtrl, decoration: InputDecoration(labelText: 'الكمية'), keyboardType: TextInputType.number)),
                    SizedBox(width: 6),
                    Expanded(child: TextField(controller: _itemPriceCtrl, decoration: InputDecoration(labelText: 'السعر'), keyboardType: TextInputType.number)),
                    SizedBox(width: 6),
                    ElevatedButton(
                      child: Text('إضافة'),
                      onPressed: () {
                        double qty = double.tryParse(_itemQtyCtrl.text) ?? 0;
                        double price = double.tryParse(_itemPriceCtrl.text) ?? 0;
                        if (_itemNameCtrl.text.isEmpty || qty <=0 || price <=0) return;
                        setState(() {
                          purchaseItems.add({
                            'name': _itemNameCtrl.text,
                            'qty': qty,
                            'price': price,
                            'total': qty*price,
                          });
                          _itemNameCtrl.clear(); _itemQtyCtrl.clear(); _itemPriceCtrl.clear();
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(height: 12),
                ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: purchaseItems.length,
                  itemBuilder: (_, index) {
                    final item = purchaseItems[index];
                    return ListTile(
                      title: Text(item['name']),
                      subtitle: Text('${item['qty']} × ${item['price']} = ${item['total']} $currency'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            purchaseItems.removeAt(index);
                          });
                        },
                      ),
                    );
                  },
                ),
                Divider(),
                Text('المجموع الكلي: $total $currency', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 12),
                Center(
                  child: ElevatedButton(
                    child: Text('حفظ الفاتورة'),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم حفظ فاتورة المشتريات مؤقتًا')));
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}