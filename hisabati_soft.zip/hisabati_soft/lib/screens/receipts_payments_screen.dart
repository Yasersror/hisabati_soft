import 'package:flutter/material.dart';

class ReceiptsPaymentsScreen extends StatefulWidget {
  @override
  _ReceiptsPaymentsScreenState createState() => _ReceiptsPaymentsScreenState();
}

class _ReceiptsPaymentsScreenState extends State<ReceiptsPaymentsScreen> {
  final _voucherNoCtrl = TextEditingController();
  final _dateCtrl = TextEditingController(text: DateTime.now().toString().split(' ')[0]);
  final _amountCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String type = 'قبض'; // أو 'صرف'

  List<Map<String, String>> vouchers = [];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('سندات القبض والصرف')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                children: [
                  DropdownButton<String>(
                    value: type,
                    items: ['قبض', 'صرف'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (val) { setState(() { type = val!; }); },
                  ),
                  SizedBox(width: 10),
                  Expanded(child: TextField(controller: _voucherNoCtrl, decoration: InputDecoration(labelText: 'رقم السند'))),
                ],
              ),
              TextField(controller: _dateCtrl, decoration: InputDecoration(labelText: 'التاريخ')),
              TextField(controller: _amountCtrl, decoration: InputDecoration(labelText: 'المبلغ'), keyboardType: TextInputType.number),
              TextField(controller: _notesCtrl, decoration: InputDecoration(labelText: 'ملاحظات')),
              SizedBox(height: 10),
              ElevatedButton(
                child: Text('إضافة السند'),
                onPressed: () {
                  if (_voucherNoCtrl.text.isEmpty || _amountCtrl.text.isEmpty) return;
                  setState(() {
                    vouchers.add({
                      'type': type,
                      'voucherNo': _voucherNoCtrl.text,
                      'date': _dateCtrl.text,
                      'amount': _amountCtrl.text,
                      'notes': _notesCtrl.text,
                    });
                    _voucherNoCtrl.clear(); _amountCtrl.clear(); _notesCtrl.clear();
                  });
                },
              ),
              SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: vouchers.length,
                  itemBuilder: (_, index) {
                    final v = vouchers[index];
                    return ListTile(
                      title: Text('${v['voucherNo']} (${v['type']})'),
                      subtitle: Text('المبلغ: ${v['amount']} - التاريخ: ${v['date']}\nملاحظات: ${v['notes']}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () { setState(() { vouchers.removeAt(index); }); },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}