import 'package:flutter/material.dart';

class CustomersSuppliersScreen extends StatefulWidget {
  @override
  _CustomersSuppliersScreenState createState() => _CustomersSuppliersScreenState();
}

class _CustomersSuppliersScreenState extends State<CustomersSuppliersScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String type = 'عميل'; // أو 'مورد'

  List<Map<String, String>> records = [];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('إضافة العملاء والموردين')),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                children: [
                  DropdownButton<String>(
                    value: type,
                    items: ['عميل', 'مورد'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (val) { setState(() { type = val!; }); },
                  ),
                  SizedBox(width: 10),
                  Expanded(child: TextField(controller: _nameCtrl, decoration: InputDecoration(labelText: 'الاسم'))),
                ],
              ),
              TextField(controller: _phoneCtrl, decoration: InputDecoration(labelText: 'رقم الهاتف')),
              TextField(controller: _notesCtrl, decoration: InputDecoration(labelText: 'ملاحظات')),
              SizedBox(height: 10),
              ElevatedButton(
                child: Text('إضافة'),
                onPressed: () {
                  if (_nameCtrl.text.isEmpty) return;
                  setState(() {
                    records.add({
                      'type': type,
                      'name': _nameCtrl.text,
                      'phone': _phoneCtrl.text,
                      'notes': _notesCtrl.text,
                    });
                    _nameCtrl.clear(); _phoneCtrl.clear(); _notesCtrl.clear();
                  });
                },
              ),
              SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: records.length,
                  itemBuilder: (_, index) {
                    final r = records[index];
                    return ListTile(
                      title: Text('${r['name']} (${r['type']})'),
                      subtitle: Text('الهاتف: ${r['phone']}\nملاحظات: ${r['notes']}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() { records.removeAt(index); });
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}