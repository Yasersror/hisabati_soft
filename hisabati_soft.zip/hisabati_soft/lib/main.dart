import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(HisabatiSoftApp());
}

class HisabatiSoftApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حساباتي سوفت',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Cairo',
      ),
      home: SplashScreen(),
    );
  }
}